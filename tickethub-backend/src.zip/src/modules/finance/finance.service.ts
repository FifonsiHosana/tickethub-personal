import config from '@/config/config.js';
import { db } from '@/db/client.js';
import { eq } from 'drizzle-orm';
import {
  payments,
  ticketOrders,
  ticketConfigurations,
  ticketOrderItems,
  eventTickets,
  tickets,
  events,
  eventsVenues,
  ticketTypes,
} from '@/db/schema/index.js';
import { sendMail } from '@/modules/emails/emails.service.js';
import { ensureAccountForOrder } from '@/modules/attendee/guest-account.service.js';
import axios from 'axios';
import type { purchaseTicketPaymentInput } from './finance.schema.js';
import { now } from '@/utils/timeDatehelpers.js';
import { buildPurchaseConfirmationEmail } from '../emails/templates/ticketPurchase.template.js';
import { computeOrderBreakdown } from './finance.pricing.js';

// eventually have a settings table, that would have the current provider
// on the admin dashboard
// right now i use a default value paystack
const PROVIDER = 'paystack';

export class FinanceService {
  async switchToPaymentMethod(payload: purchaseTicketPaymentInput) {
    if (PROVIDER === 'paystack') {
      return this.handlePayStackPayment(payload);
    }

    return this.handleHubtelPayment();
  }

  async listMobileMoneyPlatforms() {
    const response = await axios.get(
      'https://api.paystack.co/bank?country=ghana&type=mobile_money',
      {
        headers: {
          Authorization: `Bearer ${config.payment.paystack_api_key}`,
          'Content-Type': 'application/json',
        },
      },
    );

    return response.data.data;
  }

  async listBanks() {
    const response = await axios.get(
      'https://api.paystack.co/bank?country=ghana&type=ghipss',
      {
        headers: {
          Authorization: `Bearer ${config.payment.paystack_api_key}`,
        },
      },
    );

    return response.data.data;
  }

  private async handlePayStackPayment(data: purchaseTicketPaymentInput) {
    const { subtotal, feeAmount, totalAmount } = await computeOrderBreakdown(
      data.orderId,
    );

    const response = await axios.post(
      'https://api.paystack.co/transaction/initialize',
      JSON.stringify({
        email: data.email,
        amount: Math.round(totalAmount * 100),

        metadata: {
          orderId: data.orderId,
          phoneNumber: data.phoneNumber,
        },
      }),
      {
        headers: {
          Authorization: `Bearer ${config.payment.paystack_api_key}`,
          'Content-Type': 'application/json',
        },
      },
    );

    const result = response.data;

    if (!result.status) {
      throw new Error('Paystack initialization failed');
    }

    return {
      checkoutUrl: result.data.authorization_url as string,
      reference: result.data.reference as string,
      access_code: result.data.access_code as string,
      subtotal,
      feeAmount,
      totalAmount,
    };
  }

  private async handleHubtelPayment() {}

  async isTransactionProcessed(reference: string): Promise<boolean> {
    const [existingPayment] = await db
      .select({ id: payments.id })
      .from(payments)
      .where(eq(payments.reference, reference))
      .limit(1);

    return !!existingPayment;
  }

  async processPurchase(
    orderId: number,
    paymentReference: string,
    amount: number,
    currency: string,
    provider: string,
    customerEmail: string,
  ) {
    const amountToString = amount.toString();
    const { subtotal, feeAmount } = await computeOrderBreakdown(orderId);
    await db.transaction(async (tx) => {
      /**
       * ensure order exists
       */
      const [order] = await tx
        .select()
        .from(ticketOrders)
        .where(eq(ticketOrders.id, orderId))
        .limit(1);

      if (!order) {
        throw new Error('Order not found');
      }

      /**
       * create payment record
       */
      await tx.insert(payments).values({
        orderId: orderId,
        provider,
        reference: paymentReference,
        amount: amountToString,
        subtotal: subtotal.toString(),
        feeAmount: feeAmount.toString(),
        currency,
        status: 'Completed',
        paidAt: now(),
      } as typeof payments.$inferInsert);

      /**
       * mark order completed
       */
      await tx
        .update(ticketOrders)
        .set({
          status: 'Completed',
        })
        .where(eq(ticketOrders.id, orderId));

      /**
       * create a background account for a guest buyer (null password)
       * and link the order to it
       */
      const { accountCreated } = await ensureAccountForOrder(
        tx,
        orderId,
        customerEmail,
      );

      /**
       * get purchased tickets
       */
      const purchasedTickets = await tx
        .select({
          eventTicketId: ticketOrderItems.eventTicketId,
        })
        .from(ticketOrderItems)
        .where(eq(ticketOrderItems.orderId, orderId));

      /**
       * reduce inventory
       */
      for (const ticket of purchasedTickets) {
        const [configuration] = await tx
          .select({
            id: ticketConfigurations.id,
            totalSold: ticketConfigurations.totalSold,
            totalRemaining: ticketConfigurations.totalRemaining,
          })
          .from(eventTickets)
          .innerJoin(
            ticketConfigurations,
            eq(eventTickets.ticketConfigurationId, ticketConfigurations.id),
          )
          .where(eq(eventTickets.id, ticket.eventTicketId as number));

        if (!configuration) {
          continue;
        }

        await tx
          .update(ticketConfigurations)
          .set({
            totalSold: configuration.totalSold + 1,
            totalRemaining: configuration.totalRemaining - 1,
          })
          .where(eq(ticketConfigurations.id, configuration.id));
      }

      /**
       * fetch complete order details
       * (for email)
       */
      const orderItems = await tx
        .select({
          ticketIdentifier: ticketOrderItems.ticketIdentifier,
          ticketType: ticketTypes.name,
          price: ticketConfigurations.price,
          eventName: events.title,
          eventDate: events.dateAndTime,
          venueName: eventsVenues.venue_name,
          qrCodeUrl: ticketOrderItems.qrCodeUrl,
        })
        .from(ticketOrderItems)
        .innerJoin(
          eventTickets,
          eq(ticketOrderItems.eventTicketId, eventTickets.id),
        )
        .innerJoin(tickets, eq(eventTickets.ticketId, tickets.id))
        .innerJoin(events, eq(tickets.eventId, events.id))
        .innerJoin(eventsVenues, eq(events.eventVenueId, eventsVenues.id))
        .innerJoin(ticketTypes, eq(eventTickets.ticketTypeId, ticketTypes.id))
        .innerJoin(
          ticketConfigurations,
          eq(eventTickets.ticketConfigurationId, ticketConfigurations.id),
        )
        .where(eq(ticketOrderItems.orderId, orderId));

      /**
       * send email
       */
      const { html: emailHtml, attachments } =
        await buildPurchaseConfirmationEmail({
          orderId,
          items: orderItems,
          total: amount,
          accountCreated,
          email: customerEmail,
        });
      await sendMail(
        customerEmail,
        'Your TicketHub Tickets',
        'Your ticket purchase has been confirmed',
        emailHtml,
        undefined,
        attachments,
      );
    });
  }

  async handlePaystackWebhook(payload: any) {
    if (payload.event !== 'charge.success') return;

    console.log(
      `This is the payload from the paystack hoook ${JSON.stringify(payload)}`,
    );

    const orderId = Number(payload.data.metadata.orderId);
    // const phoneNumber = payload.data.metadata.phoneNumber; // later on would send SMS to this number
    const paymentRef = payload.data.reference;
    const currency = payload.data.currency;
    const email = payload.data.customer.email;
    const amount = payload.data.amount / 100;

    if (!orderId) {
      throw new Error('Missing orderId in Paystack Webhook Metadata');
    }
    const alreadyProcessed = await this.isTransactionProcessed(paymentRef);
    if (alreadyProcessed) return;

    await this.processPurchase(
      orderId,
      paymentRef,
      amount,
      currency,
      PROVIDER,
      email,
    );
  }
}
